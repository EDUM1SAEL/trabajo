num=int(input("ingrese un numero entero :"))
if(num>0):
    mensaje="el numero es positivo";
elif(num==0):
    mensaje="el numero es neutro";
else:
    mensaje="el numero es negativo";


print(num,mensaje);