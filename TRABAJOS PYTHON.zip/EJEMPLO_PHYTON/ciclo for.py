for i in range (20,0,-1):
    print (i);